# Жасыл мектеп

Одностраничный сайт «Жасыл мектеп» (kk / ru / en). Весь контент (картинки и видео) встроен в `index.html`.

## Запуск
Откройте `index.html` в браузере.

## GitHub Pages
Settings → Pages → Branch: `main`, папка `/ (root)`.
